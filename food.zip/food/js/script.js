// function FormValidation(){
// 	//alert("Alert")
// 	var name=document.custom_form.name;
// 	var email=document.custom_form.email;
// 	var phone=document.custom_form.phone;
// 	var subject=document.custom_form.subject;
// 	var message=document.custom_form.message;
// 	var conditions=document.custom_form.conditions;
	
// 	if (name.value == "") {
// 	   name.nextElementSibling.style.display = "block";
// 	   name.style.border = "1px solid #fac031";
// 	   return false
// 	}else{
// 		name.nextElementSibling.style.display = "none";
// 		name.style.border = "1px solid transparent";
// 	}
// 	if (!email.value.match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/) || email.value == "") {
// 	   email.nextElementSibling.style.display = "block";
// 	   email.style.border = "1px solid #fac031";
// 	   return false
// 	}else{
// 		email.nextElementSibling.style.display = "none";
// 		email.style.border = "1px solid transparent";
// 	}
// 	if (!phone.value.match( /^\(?([5-9]{1})\)?([0-9]{9})$/) || phone.value == "") {
// 	   phone.nextElementSibling.style.display = "block";
// 	   phone.style.border = "1px solid #fac031";
// 	   return false
// 	}else{
// 		phone.nextElementSibling.style.display = "none";
// 		phone.style.border = "1px solid transparent";
// 	}
// 	if (subject.value == "") {
// 	   subject.nextElementSibling.style.display = "block";
// 	   subject.style.border = "1px solid #fac031";
// 	   return false
// 	}else{
// 		subject.nextElementSibling.style.display = "none";
// 		subject.style.border = "1px solid transparent";
// 	}
// 	if (message.value == "") {
// 	   message.nextElementSibling.style.display = "block";
// 	   message.style.border = "1px solid #fac031";
// 	   return false
// 	}else{
// 		message.nextElementSibling.style.display = "none";
// 		message.style.border = "1px solid transparent";
// 	}
// }




const btnCart=document.querySelector('#cart-icon');
const cart=document.querySelector('.cart');
const btnClose=document.querySelector('#cart-close');

btnCart.addEventListener('click',()=>{
  cart.classList.add('cart-active');
});

btnClose.addEventListener('click',()=>{
  cart.classList.remove('cart-active');
});


// const shopCart=document.querySelector('#search-shop');
// const searchcart=document.querySelector('.search-cart');
// const searchClose=document.querySelector('#search-close');

// btnCart.addEventListener('click',()=>{
//   cart.classList.add('searchcart-active');
// });

// btnClose.addEventListener('click',()=>{
//   cart.classList.remove('searchcart-active');
// });

document.querySelector('#search-input').addEventListener('input',FilterList)
function FilterList(){
	const searchInput=document.querySelector('#search-input');
	const filter = searchInput.value.toLowerCase();
	const listItems = document.querySelectorAll('.list-group-item');
	listItems.forEach((item) =>{
		let text = item.textContent;
		if(text.toLowerCase().includes(filter.toLowerCase())){
			item.style.display = '';
		}
		else{
			item.style.display = 'none';
		}
	});
}


const form = document.getElementById("form");
const username = document.getElementById("username");
const email = document.getElementById("email");
const password = document.getElementById("message");
// const password2 = document.getElementById("password2");
const phonenumbers = document.getElementById("phonenumber");

form.addEventListener('submit',e =>{
    e.preventDefault();
    checkInput();

});

function checkInput(){
    const userValue = username.value.trim();
    const emailValue = email.value.trim();
    const passwordValue = password.value.trim();
    // const password2Value = password2.value.trim();
    const phonenumberValue = phonenumbers.value.trim();

    if(userValue === ''){
        setError(username, 'Username Cannot Be Blank');
    }
    else{
        setSuccess(username);
    }

    if(emailValue === ''){
        setError(email, 'Email Cannot Be Blank');
    }
    else if(!isEmail(emailValue)){
        setError(email, 'Not a valid EmailS');
    }
    else{
        setSuccess(email);
    }

    if(phonenumberValue ==''){
        setError(phonenumbers, 'Phonenumber Cannot Be Blank');
    }
  
    else{
        setSuccess(phonenumbers);
    }

    if(passwordValue == ''){
        setError(password, 'Password Cannot Be Blank');
    }
    else{
        setSuccess(password);
    }


    // if(password2Value == ''){
    //     setError(password2, 'Password Cannot Be Blank');
    // } 
    // else if(passwordValue != password2Value){
    //     setError(password2,'Password Does Not Match');
    // }
    // else{
    //     setSuccess(password2);
    // }

    function setError(input, message){
        const formControl = input.parentElement;
        const small = formControl.querySelector('small');
        formControl.className = 'form-controls error';
        small.innerText = message;
    }

    function setSuccess(input){
        const formControl = input.parentElement;
        formControl.className = 'form-controls success';
    }

    function isEmail(email){
        return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
    }
   
}


function myforms() {
  document.getElementById("form").reset();
}

function myFunction() {
    document.getElementById("briyani").innerHTML='';
  }
  function pastFunction() {
  
    document.getElementById("past").innerHTML='';
  }

  function lasagnaFunction() {
  
    document.getElementById("lasagna").innerHTML='';
  }
  function icecreamFunction() {
  
    document.getElementById("icecream").innerHTML='';
  }
  function chocolateFunction() {
  
    document.getElementById("chocolate").innerHTML='';
  }
  function cakeFunction() {
  
    document.getElementById("cake").innerHTML='';
  }

  $(".heart").click(function() {
    $(this).find("i").toggleClass("fa fa-heart");
    
      return v === 'Like' ? 'Unlike' : 'Like'
    })